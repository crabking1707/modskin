CÁCH DÙNG
1) Giải nén, giữ nguyên: index.html, data.js, thư mục assets/ (cùng 1 thư mục). Mở bằng web server (vd: Firebase Hosting, GitHub Pages, hoặc `python3 -m http.server`).
2) Firebase Console: tạo project -> Authentication bật "Email/Password" -> tạo Firestore Database.
3) Dán firebaseConfig vào đầu <script type="module"> trong index.html (khi chưa dán, web chạy chế độ demo lưu localStorage).
4) Firestore -> Rules: dán nội dung firestore.rules -> Publish.
5) Admin: đăng ký bằng baohieudeptrai.2009@gmail.com rồi bấm link xác minh trong email (rules chỉ cho admin khi email đã xác minh).
   Admin bấm vào con số lượt trên đầu để sửa; hoặc bấm avatar -> "Quản lý người dùng" để cấp lượt cho người khác.
